int main(){
  return (3+4*(2-1));
}
