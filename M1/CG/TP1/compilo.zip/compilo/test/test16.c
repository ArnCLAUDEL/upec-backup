long x;

int main(){
  x=2;
  return x;
}
