long f(long x, long y){
  return x+y;
} 

int main(){
  return f(3,4);
}
