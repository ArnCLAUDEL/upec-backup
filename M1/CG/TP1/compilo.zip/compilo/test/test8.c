long f(long a, long b, long c, long d, long e, long f, long g, long h){
  return g+f+h+a;
}

int main(){
  return f(1,2,3,4,5,6,7,8);
}
