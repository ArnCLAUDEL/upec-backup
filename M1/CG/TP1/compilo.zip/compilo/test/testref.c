int main(){
  const int x = 3+2-1;
  int* y =&x;
  printf("%i,%i",x,y);
}
