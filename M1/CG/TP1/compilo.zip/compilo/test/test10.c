int main(int argc, char ** argv){
  printf(argv[(argc-1)]);
  return 0;
}
