#include <stdio.h>

int main(){
  printf("test%i\n",42);
  {
    long x;
    printf("test2");
  }
  return 0;
}
