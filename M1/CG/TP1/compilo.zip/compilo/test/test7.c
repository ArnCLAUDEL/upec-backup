long f(long x,long y){
  x=20;
  return x-y;
}

int main(){
  int x ;
  x=5;
  x=f(3,x);
  return x;
}
