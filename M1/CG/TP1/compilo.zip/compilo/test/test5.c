int main(){
  long x,y;
  x=3;
  y=5;
  return (x+2*y);
}
