(* Syntaxe abstraite *)
type expr =
  | ECst of int
  | EAdd of expr * expr
  | ENeg of expr

(* Constructeurs d'expressions *)
let cst i = ECst i

let add e1 e2 = EAdd (e1, e2)

let neg e = ENeg e

(* Conversion en chaîne de caractères pour affichage *)
let rec string_of_expr e = match e with
  | ECst i -> string_of_int i
  | EAdd (e1, e2) -> Printf.sprintf "(%s) + (%s)" (string_of_expr e1) (string_of_expr e2)
  | ENeg e -> Printf.sprintf "-(%s)" (string_of_expr e)

(* Evaluateur *)
let rec eval e = match e with
  | ECst i -> i
  | EAdd (e1, e2) -> (eval e1) + (eval e2)
  | ENeg e -> - (eval e)

